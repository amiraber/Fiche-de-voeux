package com.departement.fichedevoeux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FichedevoeuxApplicationTests {

 @Test
 void contextLoads() {
 }

}