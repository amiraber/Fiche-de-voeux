package com.departement.fichedevoeux.model;

public enum Grade {
	PROF, MAB, MAA, MCB, MCA;
}
